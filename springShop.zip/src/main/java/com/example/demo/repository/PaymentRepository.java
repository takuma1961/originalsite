package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
	// 必要に応じて、カスタムクエリメソッドを追加できます。
}
